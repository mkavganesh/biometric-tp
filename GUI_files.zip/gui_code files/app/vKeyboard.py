
  
import tkinter as tk

COLOR1 = 'gray'
COLOR2 = 'white'
COLOR3 = 'black'

KEY_HEIGHT = 2
KEY_WIDTH = 2
PAD_X = 1
PAD_Y = 1
KEY_BORDER = 1

alphabets = [
    ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 'Backspace'],
    ['Tab', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', "\\"],
    ['Caps Lock', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'", 'Enter'],
    ['Shift', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 'Shift'],
    ['Space']
]

keys = [
    [
        ['`', '~'],
        ['1', '@'],
        ['2', '#'],
        ['3', '#'],
        ['4', '$'],
        ['5', '%'],
        ['6', '^'],
        ['7', '&'],
        ['8', '*'],
        ['9', '('],
        ['0', ')'],
        ['-', '_'],
        ['=', '+'],
        ['Bspace', 'Bspace'],
    ],

        [
        ['Tab', 'Tab'],
        ['q', 'Q'],
        ['w', 'W'],
        ['e', 'E'],
        ['r', 'R'],
        ['t', 'T'],
        ['y', 'Y'],
        ['u', 'U'],
        ['i', 'I'],
        ['o', 'O'],
        ['p', 'P'],
        ['[', '{'],
        [']', '}'],
        ['\\', '|'],
    ],

    [
        ['CsLock', 'CsLock'],
        ['a', 'A'],
        ['s', 'S'],
        ['d', 'D'],
        ['f', 'F'],
        ['g', 'G'],
        ['h', 'H'],
        ['j', 'J'],
        ['k', 'K'],
        ['l', 'L'],
        [';', ':'],
        ['\'', '"'],
        ['Enter', 'Enter'],
    ],

    [
        ['Shift', 'Shift'],
        ['z', 'Z'],
        ['x', 'X'],
        ['c', 'C'],
        ['v', 'V'],
        ['b', 'B'],
        ['n', 'N'],
        ['m', 'M'],
        [',', '<'],
        ['.', '>'],
        ['/', '?'],
        ['Shift', 'Shift'],
    ],

    [
        ['Space', 'Space'],
    ],
]

btn_text = {}
btn_values = {}

# keys = [
#     ['` ~', '1 @', '2 #', '3 #', '4 $', '5 %', '6 ^', '7 &',
#         '8 *', '9 (', '0 )', '- _', '= +', 'Backspace Backspace'],
#     ['Tab Tab', 'q Q', 'w W', 'e E', 'r R', 't T', 'y Y', 'u U', 'i I', 'o O', 'p P', '[ {', '] }', "\\ |"],
#     ['CsLock CsLock', 'a A', 's S', 'd D', 'f F', 'g G',
#         'h H', 'j J', 'k K', 'l L', '; :', "' \"", 'Enter Enter'],
#     ['Shift Shift', 'z Z', 'x X', 'c C', 'v V', 'b B',
#         'n N', 'm M', ', <', '. >', '/ ?', 'Shift Shift'],
#     ['Space Space']
# ]

# for i in range(len(keys)):
#     print('[')
#     for j in range(len(keys[i])):
#         temp = keys[i][j].split(' ')
#         print('[\'{}\', \'{}\'], '.format(temp[0], temp[1]))
#     print('],\n')

# uppercase = False  # use uppercase chars.
isCapsLockOn = False
isShiftOn = False
CapsLockButton = None
ShiftButtons = []



def select(entry, value):
    # global uppercase
    global isShiftOn
    global isCapsLockOn
    global btn_text
    global btn_values

    entry.configure(state='normal')

    if value == "Space":
        entry.insert('end', ' ')
        return
    elif value == 'Enter':
        entry.insert('end', '\n')
        return
    elif value == 'Tab':
        entry.insert('end', '\t')
        return

    if value == "Bspace":
        if isinstance(entry, tk.Entry):
            entry.delete(len(entry.get())-1, 'end')
        #elif isinstance(entry, tk.Text):
        else:  # tk.Text
            entry.delete('end - 2c', 'end')
    elif value == 'CsLock':
        isCapsLockOn = not isCapsLockOn  # change True to False, or False to True
        change_value()
    elif value ==  'Shift':
        isShiftOn = not isShiftOn  # change True to False, or False to True
        change_value()
    else:
        # if uppercase:
        #     value = value.upper()
        if isCapsLockOn ^ isShiftOn:
            value = btn_values[value][1]
        entry.insert('end', value)
        if isShiftOn:
            isShiftOn = False
            change_value()
    entry.configure(state='disabled')


def change_value():
    global isShiftOn
    global isCapsLockOn
    global btn_text
    global btn_values
    keys = btn_text.keys()
    for i in keys:
        if isCapsLockOn ^ isShiftOn:
            btn_text[i].set(btn_values[i][1])
        else:
            btn_text[i].set(btn_values[i][0])
    
    if isCapsLockOn:
        CapsLockButton.configure(bg=COLOR2)
    else:
        CapsLockButton.configure(bg=COLOR1)
    if isShiftOn:
        for i in ShiftButtons:
            i.configure(bg=COLOR2)
    else:
        for i in ShiftButtons:
            i.configure(bg=COLOR1)

def create(root, entry):

    global btn_text
    global btn_values
    global isCapsLockOn
    global isShiftOn
    global CapsLockButton
    global ShiftButtons


    isCapsLockOn = False
    isShiftOn = False
    btn_text = {}
    btn_values = {}
    CapsLockButton = None
    ShiftButtons = []

    window = tk.Toplevel(root)
    window.configure(background=COLOR1, )
    window.wm_attributes("-alpha", 0.9)

    # for y, row in enumerate(alphabets):

    #     x = 0

    #     #for x, text in enumerate(row):
    #     for text in row:

    #         if text in ('Enter', 'Shift'):
    #             width = 15
    #             columnspan = 2
    #         elif text == 'Space':
    #             width = 130
    #             columnspan = 16
    #         else:
    #             width = 5
    #             columnspan = 1

    #         btn_text[text] = tk.StringVar(window, text)

    #         tk.Button(window, textvariable=btn_text[text], width=width,
    #                   command=lambda value=text: select(entry, value),
    #                   padx=3, pady=3, bd=12, bg="black", fg="white"
    #                   ).grid(row=y, column=x, columnspan=columnspan)

    #         x += columnspan

    for i in range(len(keys)):
        temp = 0
        #for x, text in enumerate(row):
        for j in range(len(keys[i])):
            if keys[i][j][0] == 'Enter':
                width = KEY_WIDTH * 4
                columnspan = 4
            elif keys[i][j][0] == 'CsLock':
                width = KEY_WIDTH * 4
                columnspan = 4
            elif keys[i][j][0] == 'Bspace':
                width = KEY_WIDTH * 4
                columnspan = 4
            elif keys[i][j][0] == '\\':
                width = KEY_WIDTH * 3
                columnspan = 3
            elif keys[i][j][0] == 'Tab':
                width = KEY_WIDTH * 3
                columnspan = 3
            elif keys[i][j][0] == 'Shift':
                width = KEY_WIDTH * 5
                columnspan = 5
            elif keys[i][j][0] == 'Space':
                width = KEY_WIDTH * 32
                columnspan = 32
            else:
                width = KEY_WIDTH * 2
                columnspan = 2

            btn_text[keys[i][j][0]] = tk.StringVar(window, keys[i][j][0])
            btn_values[keys[i][j][0]] = keys[i][j]

            if keys[i][j][0] == 'CsLock':
                CapsLockButton =  tk.Button(window, textvariable=btn_text[keys[i][j][0]], width=width,
                      command=lambda value=keys[i][j][0]: select(entry, value),
                       bd=KEY_BORDER, bg=COLOR1, fg=COLOR3
                      )
                CapsLockButton.grid(
                    row=i, column=temp, padx=PAD_X, pady=PAD_Y, columnspan=columnspan)
            elif keys[i][j][0] == 'Shift':
                ShiftButtons.append(
                    tk.Button(window, textvariable=btn_text[keys[i][j][0]], width=width,
                              command=lambda value=keys[i][j][0]: select(
                                  entry, value), bd=KEY_BORDER,  bg=COLOR1, fg=COLOR3
                              )
                )
                ShiftButtons[-1].grid(row=i, column=temp,
                                      padx=PAD_X, pady=PAD_Y,
                                      columnspan=columnspan)
            else:
                temp_button = tk.Button(window, textvariable=btn_text[keys[i][j][0]], width=width,
                        command=lambda value=keys[i][j][0]: select(entry, value),
                           bd=KEY_BORDER,  bg=COLOR1, fg=COLOR3
                          )
                temp_button.grid(row=i, padx=PAD_X, pady=PAD_Y,
                                 column=temp, columnspan=columnspan)
            temp += columnspan


    change_value()
    # for i in btn_text:
    #     print(i)
# --- main ---


# if __name__ == '__main__':
#     root = tk.Tk()
#     root.title('Test Keyboard')

#     label = tk.Label(root, text='Test Keyboard')
#     label.grid(row=0, column=0, columnspan=2)

#     entry1 = tk.Entry(root)
#     entry1.grid(row=1, column=0, sticky='news')

#     button1 = tk.Button(root, text='Keyboard',
#                         command=lambda: create(root, entry1))
#     button1.grid(row=1, column=1, sticky='news')

#     # entry2 = tk.Entry(root, text='')
#     # entry2.grid(row=2, column=0, sticky='news')

#     # button2 = tk.Button(root, text='Keyboard',
#     #                     command=lambda: create(root, entry2))
#     # button2.grid(row=2, column=1, sticky='news')

#     text1 = tk.Text(root)
#     text1.grid(row=3, column=0, sticky='news')

#     button3 = tk.Button(root, text='Keyboard',
#                         command=lambda: create(root, text1))
#     button3.grid(row=3, column=1, sticky='news')

#     root.mainloop()


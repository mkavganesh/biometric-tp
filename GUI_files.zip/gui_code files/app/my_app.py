import math
import os
import random

import shutil
import threading

import time
import tkinter as tk
import tkinter.messagebox as tsmg
from difflib import SequenceMatcher
from tkinter import *
from tkinter import BOTH, E, N, S, Text, Tk, W, ttk
from tkinter.messagebox import *

import cv2
import numpy as np
import pandas as pd
import pyautogui
import pyttsx3
import torch
from facenet_pytorch import MTCNN, InceptionResnetV1
from PIL import Image, ImageTk
from sklearn import svm
from torch.utils.data import DataLoader
from torchvision import datasets

import extractor
from KSD.src import *
from MouseLogger import *
from vKeyboard import *
import torch

engine = pyttsx3.init()
def speak(text):
  engine.say(text)
  engine.runAndWait()
  
  
LARGEFONT =("Verdana", 25)
callCounter=0
count=False
uname = ''
pwd =''
cpwd = ''
global_sentence = ''

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print('Running on device: {}'.format(device))
#mtcnn = MTCNN(image_size=160, margin=0, min_face_size=20,
              #thresholds=[0.6, 0.7, 0.7], factor=0.709, post_process=True,
              #device=device) 
#resnet = InceptionResnetV1(pretrained='vggface2').eval().to(device)

mtcnn = torch.load("mtcnn.pt").eval().to(device)
resnet = torch.load("model.pt").eval().to(device)


keyStrokeObject = None
feature = Feature()
global_variable_for_storing_keyboard_data = ''
keyStrokeModel = Model()


def startKeyStrokeProcess(
	logFileDirectory="",
	logFileName="KeyLog.txt"
    ):
	global keyStrokeObject
	keyStrokeObject = KeyLogger(
            # logFileDirectory=logFileDirectory,
            # logFileName=logFileName
        )
	keyStrokeObject.ready()
	keyStrokeObject.start()


def pauseUnpauseKeyStrokeProcess():
	global keyStrokeObject
	keyStrokeObject.changeRecoringFlag()


def stopKeyStrokeProcess():
	keyStrokeObject.stop()


def startKeyStroke(record_key=True,):
    if(record_key):
        thread_KeyStroke = threading.Thread(
            target=startKeyStrokeProcess,
            kwargs=dict(
                # logFileDirectory=directoryName,
                # logFileName=keyStrokeFileName,
            )
        )
        thread_KeyStroke.start()


def pauseUnpause():
	pauseUnpauseKeyStrokeProcess()


def stopKeyStroke(record_key=True):
	if record_key:
		stopKeyStrokeProcess()

mouseLogObject = None

def startMouseLogProcess(
	logFileDirectory="",
	logFileName="MouseLog.txt"
    ):
	global mouseLogObject
	mouseLogObject = MouseLogger(
            # logFileDirectory=logFileDirectory,
            # logFileName=logFileName
        )
	mouseLogObject.ready()
	mouseLogObject.start()


def pauseUnpauseMouseLogProcess():
	global mouseLogObject
	mouseLogObject.changeRecoringFlag()

def stopMouseLogProcess():
	mouseLogObject.stop()


def startMouseLog(record_key=True,):
    if(record_key):
        thread_MouseLog = threading.Thread(
            target=startMouseLogProcess,
            kwargs=dict(
                # logFileDirectory=directoryName,
                # logFileName=keyStrokeFileName,
            )
        )
        thread_MouseLog.start()


def pauseUnpauseMouse():
	pauseUnpauseMouseLogProcess()

def stopMouseLog(record_key=True):
	if record_key:
		stopMouseLogProcess()


def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()


def verify(x, y, z):
    global uname
    global pwd
    global global_sentence
    a=uname.get()
    b=pwd.get()

    stopKeyStroke()
    stopMouseLog()

    originalTxt = x['text']
    keyboardTxt = y.get('1.0',END)
    mouseTxt = z.get('1.0', END)
	
    mix=a+"-"+b+"-"+b
    d = ['']
    
    
    try:
        with open(a + '/' + "password.txt","r") as fi:
            
            d=fi.readlines()
            print("Yes",d)
        
    except:
        d=""
        pass
    
    if similarity(originalTxt, mouseTxt) >0.9 and similarity(originalTxt, keyboardTxt)>0.9:
        print(b, d)
        if d != "":
            if str(b) == str(d[0]):
                face_score=0
            
                hold, dd, ud = feature.extractFeatures(keyStrokeObject.string)
                keyStrokeModel.fit([hold, dd, ud])
                # keyStrokeModel.save_model(a + '/' + '/keyStrokeModel')
                keyStrokeModel_original = keyStrokeModel.load_model(
                    a + '/' + '/keyStrokeModel')
                keyStrokeScore = keyStrokeModel_original.check_similarity(keyStrokeModel)
                # print(keyStrokeModel_original.models)
                # print(keyStrokeModel.models)
                if keyStrokeScore > 0.90:
                    keyStrokeModel_original.update([hold, dd, ud])
                    keyStrokeModel_original.save_model(a + '/' + '/keyStrokeModel')
            
                temp_mousestring = mouseLogObject.string
                mouse_train= extractor.features(temp_mousestring)
                saved_model = mouseLogObject.load_mousemodel(a + '/' + '/mouseLogModel')
                result = saved_model.predict(mouse_train)
                count=0
                for i in range(result.shape[0]):
                    if (result[i]==1):
                        count=count+1
            
                acc=(count*100)/result.shape[0]        
            
                print(keyStrokeScore)
                print(acc)
                print(face_score,"Face score")
                
                    
                face_score,live_score=verify_face()
                if face_score==2 and live_score==2 and keyStrokeScore >0.7 and acc>0.1:
                    displayString = "Hello, You Have SuccessFully Logged In"
                    tsmg.showinfo('Welcome, ', displayString)
                    to_write="0\t1\t"+str(face_score)+'\t'+str(live_score)+'\t'+str(keyStrokeScore)+'\t'+str(acc)+'\t'+'\n'
                    
                    
                else:
                    to_write="0\t0\t"+str(face_score)+'\t'+str(live_score)+'\t'+str(keyStrokeScore)+'\t'+str(acc)+'\t'+'\n'

                    tsmg.showinfo('Error, ', "Access Denied")
            else:
                to_write="0\t-1\t"+str(0)+'\t'+str(0)+'\t'+str(0)+'\t'+str(0)+'\t'+'\n'

                tsmg.showerror("Error","User name and Password are not matching")
        else:
            tsmg.showerror("Error","No User Found, Please Sign-Up First")
    else:
        to_write="0\t-2\t"+str(0)+'\t'+str(0)+'\t'+str(0)+'\t'+str(0)+'\t'+'\n'

        tsmg.showerror("Error","Keyboard and mouse input are not matching")

    f=open(a + '/' + "logs.txt","a")
    f.write(to_write)
    f.close()
    uname.set("")
    pwd.set("")
    y.delete('1.0', END)
    z.configure(state='normal')
    z.delete('1.0', END)
    z.configure(state='disabled')
    #global_sentence.set("")
    

def save(x, y, z):
    global uname
    global pwd
    global cpwd
    a=uname.get()
    b=pwd.get()
    c = cpwd.get()
    stopKeyStroke()
    stopMouseLog()

    originalTxt = x['text']
    keyboardTxt = y.get('1.0',END)
    mouseTxt = z.get('1.0', END)

    mix=a+"-"+b+"-"+c
    if a!="" and b!="" and c!="" :
        try:
            with open("Login.txt","r") as fi:
                d=fi.readlines()
        except:
            d=""
                
        if str(mix) in str(d):
            tsmg.showerror("Error","You Already Have An Account, Please Login")
            uname.set("")
            pwd.set("")
            cpwd.set("")
        elif str(a) in str(d):
            tsmg.showerror("Error","Username Already Exists")
            uname.set("")
            pwd.set("")
            cpwd.set("")
        else:
            if similarity(originalTxt, mouseTxt) >0.9 and similarity(originalTxt, keyboardTxt)>0.9:
                if b == c:
                    completePath = os.path.join(a)
                    if not os.path.exists(a):                    
                        os.mkdir(completePath)
                    f = open(completePath + '/' + 'password.txt', 'w')
                    f.write(b)
                    f.close()
                
                    tsmg.showinfo("Success", "Your Account Has Been Created")
                    hold, dd, ud = feature.extractFeatures(keyStrokeObject.string)
                    keyStrokeModel.fit([hold, dd, ud])
                    keyStrokeModel.save_model(a + '/' + '/keyStrokeModel')
                    # print(keyStrokeModel.models)
                    # print(keyStrokeModel.models)
            
                    temp_mouse_string = mouseLogObject.string
                    # mousefeaturestrain= extractor.features(temp_mouse_string)
                    # train_set = extractor.features(mousefeaturestrain)
                    train_set = extractor.features(temp_mouse_string)
                    # print('in extractor       ', train_set)
                    mouse_model = svm.OneClassSVM(kernel='rbf', gamma=0.3, nu=0.22)
                    mouse_model.fit(train_set)
                    mouseLogObject.save_mousemodel(mouse_model, a + '/' + '/mouseLogModel')
                    
                    #log file
                    f = open(completePath + '/' + 'logs.txt', 'w')
                    f.write("1\t1\t2\t2\t1\t1\n")
                    f.close()
                    
                    
                    
                    uname.set("")
                    pwd.set("")
                    cpwd.set("")
                else:
                    tsmg.showerror("Error","Passwords Are Not matched.Please type again")   
                    uname.set("")
                    pwd.set("")
                    cpwd.set("") 
            else:
                tsmg.showerror(
                    "Error", "Keyboard and mouse input are not matching")
    y.delete('1.0', END)
    z.configure(state='normal')
    z.delete('1.0', END)
    z.configure(state='disabled')

def retrieve_sentence(length=1):
    sentences = ["why do bees hum they dont remember the lyrics", "change is inevitable except from a vending machine","dont trust atoms they make up everything"]
    return np.random.choice(sentences)

def sq(x):
    return x*x


def check_right(righteye,lefteye,nose,orig_eye_dist,orig_nose_x):
    dist = math.sqrt((righteye[0]-lefteye[0])**2 + (righteye[1]-lefteye[1])**2)
    print("Right:",nose[0],orig_nose_x,dist,orig_eye_dist)
    if dist<=orig_eye_dist*0.7 and nose[0]<orig_nose_x:
        return True
    else:
        return False
    
def check_left(righteye,lefteye,nose,orig_eye_dist,orig_nose_x):
    dist = math.sqrt((righteye[0]-lefteye[0])**2 + (righteye[1]-lefteye[1])**2)
    print("Left:",nose[0],orig_nose_x,dist,orig_eye_dist)
    if dist<=orig_eye_dist*0.7 and nose[0]>orig_nose_x:
        return True
    else:
        return False
    
def check_smile(mouth_right,mouth_left,orig_mouth_dist):
    dist = math.sqrt((mouth_right[0]-mouth_left[0])**2 + (mouth_right[1]-mouth_left[1])**2)
    print("Smile:",dist,orig_mouth_dist)
    if dist>=orig_mouth_dist*1.15:
        return True
    else:
        return False
    
def check_pout(mouth_right,mouth_left,orig_mouth_dist):
    dist = math.sqrt((mouth_right[0]-mouth_left[0])**2 + (mouth_right[1]-mouth_left[1])**2)
    print("Pout;",dist,orig_mouth_dist)
    if dist<=orig_mouth_dist-5:
        return True
    else:
        return False





def liveness_tests():
    tasks = ['Right','Left','Smile']#,'Pout']
    tasks = random.sample(tasks, 2)

    font = cv2.FONT_HERSHEY_SIMPLEX
    count,tasks_completed,out = 0,0,0
    status = False
    cam = cv2.VideoCapture(0)
    flag=0

    while True:
        # image extraction from android phone camera using IP Webcam
        _,image = cam.read()
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        boxes,probs,lms = mtcnn.detect(image,landmarks=True)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        ind = np.argmax(probs)
        

        if boxes is not None:
            flag = flag + 1
            bounding_box = boxes[ind]
            keypoints = lms[ind]
            cv2.rectangle(image,(bounding_box[0], bounding_box[1]),(bounding_box[2],bounding_box[3]),(0,155,255),2)
            cv2.circle(image,tuple(keypoints[0]), 2, (0,155,255), 2)
            cv2.circle(image,tuple(keypoints[1]), 2, (0,155,255), 2)
            cv2.circle(image,tuple(keypoints[2]), 2, (0,155,255), 2)
            cv2.circle(image,tuple(keypoints[3]), 2, (0,155,255), 2)
            cv2.circle(image,tuple(keypoints[4]), 2, (0,155,255), 2)
            if count==0:
                original_eye_dist = math.sqrt((keypoints[1][0]-keypoints[0][0])**2 + (keypoints[1][1]-keypoints[0][1])**2)
                #print("Original Eye Distance = ",original_eye_dist)
                original_mouth_dist = math.sqrt((keypoints[4][0]-keypoints[3][0])**2 + (keypoints[4][1]-keypoints[3][1])**2)
                #print("Original Lip Distance = ",original_mouth_dist)
                original_nose_x = keypoints[2][0]
                count+=1
                print("done")
                continue

            task = tasks[0]
            image = cv2.resize(image,(800,800))
            speak(task)
            image = cv2.putText(image, task, (350,25), font,0.75, (255,255,255), 2)
            cv2.imshow("Test",image)
            if task == 'Right':
                status = check_right(keypoints[1],keypoints[0],keypoints[2],original_eye_dist,original_nose_x)
            elif task == 'Left':
                status = check_left(keypoints[1],keypoints[0],keypoints[2],original_eye_dist,original_nose_x)
            elif task == 'Smile':
                status = check_smile(keypoints[4],keypoints[3],original_mouth_dist)
            elif task == 'Pout':
                status = check_pout(keypoints[4],keypoints[3],original_mouth_dist)

            if status:
                tasks_completed += 1
                tasks = tasks[1:]
                flag = 0
                
            
            count +=1
        else:
            out+=1
            
        if cv2.waitKey(1) == 27 or tasks_completed == 2 or out>4 or flag>10:
            print(out,flag,out)
            break 
    cam.release()
    cv2.destroyAllWindows()
    print(tasks_completed)
    if tasks_completed == 2:
        print("Liveness Testing Complete!")
        print(" Access Granted")
        return tasks_completed
    else:
        print("Access Denied")
        return tasks_completed
    
def store_face_data():
    global uname
    flag=0
    name=uname.get()
    
    count = 0
    
    if os.path.exists(name) is False:
        os.mkdir(name) 
    if os.path.exists(name+'/face') is False:
        os.mkdir(name+'/face')  
    if os.path.exists(name+'/face_log') is False:
        os.mkdir(name+'/face_log')
    
    # = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    cam = cv2.VideoCapture(0)
    while(True):
        _,img = cam.read()
        x_img,prob = mtcnn(img,return_prob=True)
        if prob:
            if prob>=0.90:
                cv2.imwrite(name + "/face/"+str(count)+".jpg", img)
                count+=1
        cv2.imshow('image', img)     
                        
                        
        if cv2.waitKey(1) == 27 or count > 8:
            break
        
    cam.release()
    imgs=os.listdir(name+'/face')
    imgs=[os.path.join(name+'/face',item) for item in imgs]
    
    probs=[0 for i in range(len(imgs))]
    for j in range(len(imgs)):
        img=Image.open(imgs[j])
        x_aligned, prob = mtcnn(img, return_prob=True,save_path=imgs[j])
        
        if x_aligned is not None:
            print('Face detected with probability: {:8f}'.format(prob))
            probs[j] = prob
            if prob >=0.95:
                flag=1
            
    
    prob_max=np.max(probs)
    print(prob_max,":",probs)
    for i in range(len(imgs)):
        if probs[i]<prob_max:
            os.remove(imgs[i])
    if flag<1:
        tsmg.showerror("Error","Unable to detect face.Please center align in the frame")
        store_face_data()
    else:
        tsmg.showinfo("Success","Face image registered.Please click on Register button to complete registration")
        
    cv2.destroyAllWindows()
        
def verify_face():
    global uname
    name=uname.get()
    
    
    ref_img_path=os.listdir(name+'/face')
    ref_img_path=[os.path.join(name+'/face',item) for item in ref_img_path]
    ref_im=Image.open(ref_img_path[0])
    aligned=[]
    ref_img,prob=mtcnn(ref_im,return_prob=True)
    ref_img=[ref_img]
    ref_img = torch.stack(ref_img).to(device)
    ref_emb = resnet(ref_img).detach().cpu()
    
    count=0
    confirmation = 0
    face_score = 0
    no_face = 1
    cam = cv2.VideoCapture(0)
    log_count = len(os.listdir(name + '/face_log'))
    wrg_faces = []
    flag = 0
    ver_count = 0
    while count<=5 and confirmation < 2 and flag<10:
        aligned=[]
        dist = 100
        _,frame = cam.read()
        #cv2.imshow('face_verify',frame)
        x_aligned, prob = mtcnn(frame, return_prob=True)
        if x_aligned is not None:
            no_face = 0
            count+=1
            aligned.append(x_aligned)
            aligned = torch.stack(aligned).to(device)
            emb = resnet(aligned).detach().cpu()
            dist = np.linalg.norm(emb-ref_emb)
            if dist<1.1:
                confirmation+=1                
                print(dist,face_score,confirmation)
            else:
                wrg_faces.append(frame)
        else:
            flag +=1
                
    cam.release()
    cv2.destroyAllWindows()
    for i in range(len(wrg_faces)):
        log_count = log_count+1
        cv2.imwrite(name + "/face_log/"+str(log_count)+".jpg", wrg_faces[i])
    face_score = confirmation
    if confirmation >= 2:
        live_score=liveness_tests()
        if live_score ==1:
            return face_score , live_score
        else:
            return face_score , live_score
    elif no_face:
        face_score = -1
        print("No face detected")
        tsmg.showerror("Error","Please center align in the frame")
        if ver_count < 1:
            verify_face()
    else: 
       
        return face_score, -1
        
    return -1 , -1

        
        
            
        
        
        
            
            

class tkinterApp(tk.Tk):
    
    # __init__ function for class tkinterApp 
    def __init__(self, *args, **kwargs): 
        
        # __init__ function for class Tk
        tk.Tk.__init__(self, *args, **kwargs)
        global uname
        global pwd
        global cpwd
        global global_sentence
        
        uname = StringVar()
        pwd = StringVar()
        cpwd = StringVar()
        global_sentence = StringVar()
        
        
        # creating a container
        container = tk.Frame(self) 
        container.pack(side = "top", fill = "both", expand = True) 

        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)

        # initializing frames to an empty array
        self.frames = {} 

        # iterating through a tuple consisting
        # of the different page layouts
        for F in (StartPage, LoginPage, RegisterPage):

            frame = F(container, self)

            # initializing frame of that object from
            # startpage, page1, page2 respectively with 
            # for loop
            self.frames[F] = frame 

            frame.grid(row = 0, column = 0, sticky ="nsew")

        self.show_frame(StartPage)

    # to display the current frame passed as
    # parameter
    def show_frame(self, cont, y=None, z=None):
        global login_page_cap
        global register_page_cap
        global global_sentence
        global uname
        global pwd
        global cpwd
        if cont == LoginPage:
            # print('here')
            try:
                stopKeyStroke()
                stopMouseLog()
            except:
                pass
            startKeyStroke()
            startMouseLog()
            login_page_cap = True
            register_page_cap = False
        elif cont == RegisterPage:
            try:
                stopKeyStroke()
                stopMouseLog()
            except:
                pass
            startKeyStroke()
            startMouseLog()
            login_page_cap = False
            register_page_cap = True
        # print(cont)
        if y != None:
            y.delete('1.0', END)
        if z != None:
            z.configure(state='normal')
            z.delete('1.0', END)
            z.configure(state='disabled')
        uname.set("")
        pwd.set("")
        cpwd.set("")
        global_sentence.set(retrieve_sentence(3))
        frame = self.frames[cont]
        frame.tkraise()

# first window frame startpage


class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        ttk.Label(self, text="Message from the creators",
                  font=LARGEFONT).pack()
        
        Label(self, text="").pack()
        Button(self, text="Continue", command=lambda:
               controller.show_frame(LoginPage)).pack()



class LoginPage(tk.Frame):

    def __init__(self, parent, controller): 
        tk.Frame.__init__(self, parent, padx=20, pady=20)
        ttk.Label(self, text="\tLogin Page\t", font=LARGEFONT).grid(
            row=0, column=1, columnspan=2, rowspan=1, sticky='nsew')  # .pack()

        global uname
        global pwd
        global cpwd
        global global_sentence
        
        # Label(self, text="").pack()
        username_lable = Label(self, text="Username  ")
        username_lable.grid(row=1, column=1, sticky='nsew')
        # username_lable.pack()

        username_entry = Entry(self, textvariable=uname)
        username_entry.grid(row=1, column=2, sticky='nsew')
        # username_entry.pack()

        pwd_lable = Label(self, text="Password ")
        pwd_lable.grid(row=2, column=1, sticky='nsew')
        # pwd_lable.pack()

        pwd_entry = Entry(self, textvariable=pwd, show='*')
        pwd_entry.grid(row=2, column=2, sticky='nsew')
        # pwd_entry.pack()
        
        def mark() :

            if var.get() == 1 :
                pwd_entry.configure(show = "")
            elif var.get() == 0 :
                pwd_entry.configure(show = "*")
        
        var=IntVar()
        Checkbutton(self, text="Show password", command=mark, offvalue=0,
                    onvalue=1, variable=var).grid(
                        row=3, column=2, sticky='nsew')  # .pack()
        
        sentence = retrieve_sentence()
        global_sentence.set(sentence)
        Label(self, anchor='w', text='Enter the following sentence:').grid(row=4, column=1, columnspan=2,
                                                            rowspan=1, sticky='nsew')
        sentence_label = Label(self,textvariable = global_sentence)
        sentence_label.grid(row=5, column=1, columnspan=2,
                            rowspan=1, sticky='nsew')

        Label(self, anchor='w', text='Using Keyboard').grid(row=6, column=1, columnspan=2,
                                                rowspan=1, sticky='nsew')
        keyboard_text = Text(self, height = 2, width=10)
        keyboard_text.grid(row=7, column=1, columnspan=2,
                           rowspan=1, sticky='nsew')

        Label(self,  anchor='w', text='Using Mouse (click on the vKey button to start').grid(row=8, column=1, columnspan=2,
                                                                                             rowspan=1, sticky='nsew')
        mouse_text = Text(self, height=2, width=10, state="disabled")

        def clear_text():
            mouse_text.configure(state='normal')
            mouse_text.delete('1.0', END)
            mouse_text.configure(state='disabled')

        Button(self, text="Clear", command=clear_text).grid(
            row=9, column=1,  columnspan=1, padx=5, pady=5, sticky='nsew')  # .pack()
        Button(self, text="vKey", command=lambda: create(self, mouse_text)).grid(
            row=9, column=2,  columnspan=1, padx=5, pady=5, sticky='nsew')  # .pack()

        mouse_text.grid(row=10, column=1, columnspan=2,
                        rowspan=1, sticky='nsew')

        # Label(self, text="").pack()
        Button(self, text="Login", command=lambda:verify(
            sentence_label,
            keyboard_text,
            mouse_text
        )).grid(
            row=15, column=1,  columnspan=2,  padx=5, pady=5, sticky='nsew')  # .pack()
        
        # Label(self, text="").pack()
        Button(self, text ="Register",command = lambda :  
               controller.show_frame(RegisterPage, keyboard_text, mouse_text)).grid(row=16, column=1, columnspan=2, padx=5, pady=5, sticky='nsew')  # .pack()
        

# second window frame page1 
class RegisterPage(tk.Frame):
    
    def __init__(self, parent, controller):

    # def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, padx=20, pady=20)
        ttk.Label(self, text="\tSignUp Page\t", font=LARGEFONT).grid(
            row=0, column=1, columnspan=2, rowspan=1, sticky='nsew')  # .pack()

        global uname
        global pwd
        global cpwd
        global global_sentence
      

        
        # Label(self, text="").pack()
        username_lable = Label(self, text="Username  ")
        username_lable.grid(row=1, column=1, sticky='nsew')
        # username_lable.pack()

        username_entry = Entry(self, textvariable=uname)
        username_entry.grid(row=1, column=2, sticky='nsew')
        # username_entry.pack()

        pwd_lable = Label(self, text="Password ")
        pwd_lable.grid(row=2, column=1, sticky='nsew')
        # pwd_lable.pack()

        pwd_entry = Entry(self, textvariable=pwd, show='*')
        pwd_entry.grid(row=2, column=2, sticky='nsew')
        # pwd_entry.pack()

        def mark():

            if var.get() == 1:
                pwd_entry.configure(show="")
            elif var.get() == 0:
                pwd_entry.configure(show="*")

        var = IntVar()
        Checkbutton(self, text="Show password", command=mark, offvalue=0,
                    onvalue=1, variable=var).grid(
                        row=3, column=2, sticky='nsew')  # .pack()

        cpwd_lable = Label(self, text="Confirm Password ")
        cpwd_lable.grid(row=4, column=1, sticky='nsew')
        cpwd_entry = Entry(self, textvariable=cpwd, show='*')
        cpwd_entry.grid(row=4, column=2, sticky='nsew')

        def mark2():
            if var2.get() == 1:
                cpwd_entry.configure(show="")
            elif var2.get() == 0:
                cpwd_entry.configure(show="*")

        var2 = IntVar()
        Checkbutton(self, text="Show password", command=mark2, offvalue=0,
                    onvalue=1, variable=var2).grid(
                        row=5, column=2, sticky='nsew')  # .pack()

        sentence = retrieve_sentence(3)
        global_sentence.set(sentence)
        Label(self, anchor='w', text='Enter the following sentence:').grid(row=6, column=1, columnspan=2,
                                                                           rowspan=1, sticky='nsew')
        sentence_label = Label(self, textvariable=global_sentence)
        sentence_label.grid(row=7, column=1, columnspan=2,
                            rowspan=1, sticky='nsew')

        Label(self, anchor='w', text='Using Keyboard').grid(row=8, column=1, columnspan=2,
                                                            rowspan=1, sticky='nsew')
        keyboard_text = Text(self, height=4, width=10)
        keyboard_text.grid(row=9, column=1, columnspan=2,
                           rowspan=1, sticky='nsew')

        Label(self,  anchor='w', text='Using Mouse (click on the vKey button to start').grid(row=10, column=1, columnspan=2,
                                                                                             rowspan=1, sticky='nsew')
        mouse_text = Text(self, height=4, width=10, state="disabled")

        def clear_text():
            mouse_text.configure(state='normal')
            mouse_text.delete('1.0', END)
            mouse_text.configure(state='disabled')

        Button(self, text="Clear", command=clear_text).grid(
            row=11, column=1,  columnspan=1, padx=5, pady=5, sticky='nsew')  # .pack()
        Button(self, text="vKey", command=lambda: create(self, mouse_text)).grid(
            row=11, column=2,  columnspan=1, padx=5, pady=5, sticky='nsew')  # .pack()

        mouse_text.grid(row=12, column=1, columnspan=2,
                        rowspan=1, sticky='nsew')
        
        # cap = cv2.VideoCapture(0)
        
        Button(self, text="Capture Image",command=store_face_data).grid(
            row=15, column=1,  columnspan=2,  padx=5, pady=5, sticky='nsew')#.pack()


        # Label(self, text="").pack()
        Button(self, text="Register", command=lambda : save(
            sentence_label,
            keyboard_text,
            mouse_text
        )).grid(
            row=16, column=1,  columnspan=2,  padx=5, pady=5, sticky='nsew')  # .pack()

       

        Button(self, text="Go back to login page",
                   command=lambda: controller.show_frame(LoginPage, keyboard_text, mouse_text)).grid(
                       row=17, column=1, columnspan=2, padx=5, pady=5, sticky='nsew')  # .pack()
       
        # button to show frame 2 with text
        #ttk.Button(self, text ="Close",command = lambda : controller.show_frame(RegSuccess)).pack()
    
        





# Driver Code
app = tkinterApp()
app.mainloop()




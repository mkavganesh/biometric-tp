import pynput
import time
import pickle

class MouseLogger():

    def __init__(self,
                #  logFileDirectory="",
                #  logFileName="Mouse_track_Log.txt",
                 getTime=time.time):

        # self.logFileDirectory = logFileDirectory
        # self.logFileName = logFileName
        self.getTime = getTime
        self.recordingFlag = True
        self.string=''

    # def setLogFileName(self, logFileName):
    #     self.logFileName = logFileName

    # def setLogDirectoryName(self, setLogDirectory):
    #     self.logFileDirectory = logFileDirectory
	
    def setRecoringFlag(self, flag):
        self.recordingFlag = flag

    def ready(self):
        # self.file = self.returnFileForWriting()
        self.string=''

    # def returnFileForWriting(self):
    #     return open(self.logFileDirectory +'//'+ self.logFileName, "w+")

    def start(self):
        
        def track(x,y):
            # self.file.write('MM\t{}\t{}\t{}\n'.format(x,y,self.getTime()))
            # print(self.getTime())
            self.string += 'MM\t{}\t{}\t{}\n'.format(x,y,self.getTime())
            
        # def wheel_scroll(x,y,dx,dy):
        #     if dy < 0:
        #         self.file.write('MWM\t{}\t{} down \t{}\t{}\t{}\n'.format(x,y,abs(dy),dy,self.getTime()))
        #     else:
        #        self.file.write('MWM\t{}\t{} up \t{}\t{}\t{}\n'.format(x,y,abs(dy),dy,self.getTime()))
                
        def clicks(x,y,button,pressed):
            if pressed:
                #self.file.write('MC\t{}\t{}\n'.format(x,y))
                self.string += 'MC\t{}\t{}\n'.format(x,y)
            else:
                #self.file.write('MC\t{}\t{}\n'.format(x,y))
                self.string += 'MC\t{}\t{}\n'.format(x,y)
			# print('a')
                
        self.listener = pynput.mouse.Listener(on_move=track,on_click=clicks)
        self.listener.start()
	
    def changeRecoringFlag(self):
	    self.recordingFlag = not self.recordingFlag
    
    def stop(self):
        self.listener.stop()
        #self.file.close()


    
    def save_mousemodel(self, model, path='', name='mousemodel.pkl'): 
        import os
        if not os.path.exists(path + '/' + name):
            completePath = os.path.join(path)
            # print('completePath: ',completePath)
            os.mkdir(completePath)
            f = open(completePath + '/' + name, 'w')
            f.close()
        with open(path +'/mousemodel.pkl', 'wb') as out:
            pickle.dump(model, out, pickle.HIGHEST_PROTOCOL)
            # print(self.models)


    def load_mousemodel(self, path='', name='mousemodel.pkl'):
        import os
        if not os.path.exists(path + '/'+ name):
            # print()
            return None
        with open(path+'/mousemodel.pkl', 'rb') as inp:
            return pickle.load(inp)
            # print(self.models)
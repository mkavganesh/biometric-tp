
  
from datetime import datetime

class Time():

	def __init__(
		self,
		timeFormat = "%d:%m:%Y:%H:%M:%S:%f"
		):
		self.timeFormat = timeFormat

	def getTime(self):
		return datetime.now().strftime(self.timeFormat)

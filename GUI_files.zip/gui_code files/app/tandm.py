
import numpy as np
import extractor
from sklearn import svm
from sklearn import preprocessing


X_user= extractor.features()
X_user = preprocessing.scale(X_user,axis=0)

list = [18,22,33,38]
X_user = X_user[:,list]

# Choose User
Training_Data = X_user
np.random.shuffle(Training_Data)
delta = int(Training_Data.shape[0]/5)
Train_part1 = Training_Data[0:delta,:]
Train_part2 = Training_Data[delta:2*delta,:]
Train_part3 = Training_Data[2*delta:3*delta,:]
Train_part4 = Training_Data[3*delta:4*delta,:]
Train_part5 = Training_Data[4*delta:,:]

Train_Data = np.concatenate((Train_part1,Train_part2,Train_part3,Train_part4),axis=0)
def model():
    
    clf = svm.OneClassSVM(kernel='rbf', gamma=0.3, nu=0.22)
    clf.fit(Train_Data)
    return clf

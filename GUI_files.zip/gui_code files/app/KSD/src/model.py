# import numpy as np
# import scipy.stats

# class GaussianDistribution(object):

#     def __init__(self, mean=0, std=1, samples=0):
#         self.mean = mean
#         self.std = std
#         self.samples = samples

#     @staticmethod
#     def estimate_parameters(samples):
#         number = len(samples)
#         mean = np.mean(samples)
#         std = np.max(0.01*mean ,np.std(samples))
#         return mean, std, number

#     def similarity(self, obj):
#         std = (self.std - obj.std) / 2
#         diff = abs(self.mean - obj.mean)
#         return 2*scipy.stats.norm.cdf(-diff/std)

#     def similarity_number(self, number):
#         diff = abs(self.mean - number)
#         return 2*scipy.stats.norm.cdf(-diff/self.std)

#     def __repr__(self):
#         return "{}({:.2f}, {:.2f}, {})".format(self.__class__.__name__, self.mean, self.std, self.samples)


# from sklearn.mixture import GMM
import numpy as np
import scipy.stats
import pickle
# import warnings
# warnings.filterwarnings('ignore')

MINIMUM_STANDARD_DEVIATION = 0.001

class ModelSingle():

    def __init__(self, mean=0, std=1 , nsamples=0):
        self.nsamples = 0
        self.mean = mean
        self.std = std
    
    def fit(self, x):
        self.nsamples = len(x)
        self.mean = np.mean(x)
        self.std = np.std(x)
        self.std = max(self.std, self.mean * MINIMUM_STANDARD_DEVIATION)
    
    def check_similarity(self, other_object):
        std = (self.std + other_object.std) / 2.0
        diff = abs(self.mean - other_object.mean)
        return 2*scipy.stats.norm.cdf(-diff/std)
    
    def check_similarity_number(self, number):
        std = self.std
        diff = abs(self.mean - number)
        return 2*scipy.stats.norm.cdf(-diff/std)

    def update(self, x):
        sumAll = self.mean * self.nsamples
        sumSquared = self.nsamples * self.std **2 + self.mean **2
        sumAll = sumAll + np.sum(x)
        sumSquared = sumSquared + np.sum(x**2)
        self.nsamples = self.nsamples + len(x)
        self.mean = sumAll / self.nsamples
        self.std = np.sqrt((sumSquared - self.mean**2)/self.nsamples)
    
    def __repr__(self):
        return "(mean:{}, std:{}, samples:{})".format(self.mean, self.std, self.nsamples)

class Model():

    def __init__(self, nmodels=0):
        self.nmodels = nmodels
        self.models = []
        
    def fit(self, x):
        self.nmodels = len(x)
        self.models = []
        for i in range(self.nmodels):
            self.models.append(ModelSingle())
        for i in range(self.nmodels):
            self.models[i].fit(x[i])

    def check_similarity(self, other_object):
        answer = 0
        for i in range(self.nmodels):
            answer += self.models[i].check_similarity(other_object.models[i])
        print(answer)
        return answer / self.nmodels

    def update(self, x):
        for i in range(self.nmodels):
            self.models[i].update(x[i])
    
    def save_model(self, path='', name='model.pkl'): 
        import os
        if not os.path.exists(path + '/' + name):
            completePath = os.path.join(path)
            os.mkdir(completePath)
            f = open(completePath + '/' + name, 'w')
            f.close()
        with open(path +'/model.pkl', 'wb') as out:
            pickle.dump(self, out, pickle.HIGHEST_PROTOCOL)
            # print(self.models)

    def load_model(self, path='', name='model.pkl'):
        import os
        if not os.path.exists(path + '/'+ name):
            # print()
            return None
        with open(path+'/model.pkl', 'rb') as inp:
            return pickle.load(inp)
            # print(self.models)


        

# def function(a, b):
#     meana = np.mean(a)
#     stda = np.std(a)
#     meanb = np.mean(b)
#     stdb = np.std(b)
#     mean = abs(meana-meanb)
#     std = (stda + stdb)/2
#     return 2*scipy.stats.norm.cdf(-mean/std)

# SIZE = 1000
# for i in range(10):
#     a = np.random.standard_normal(SIZE) * 100
#     b = np.random.standard_normal(SIZE) *50 + 10
#     print(function(a, b))

"""
GMM
    n_components : int, optional
        Number of mixture components. Defaults to 1.

    covariance_type : string, optional
        String describing the type of covariance parameters to use. Must be one of ‘spherical’, ‘tied’, ‘diag’, ‘full’. Defaults to ‘diag’.

    random_state: RandomState or an int seed (None by default) :
        A random number generator instance

    min_covar : float, optional
        Floor on the diagonal of the covariance matrix to prevent overfitting. Defaults to 1e-3.

    tol : float, optional
        Convergence threshold. EM iterations will stop when average gain in log-likelihood is below this threshold. Defaults to 1e-3.

    n_iter : int, optional
        Number of EM iterations to perform.

    n_init : int, optional
        Number of initializations to perform. the best results is kept

    params : string, optional
        Controls which parameters are updated in the training process. Can contain any combination of ‘w’ for weights, ‘m’ for means, and ‘c’ for covars. Defaults to ‘wmc’.

    init_params : string, optional
        Controls which parameters are updated in the initialization process. Can contain any combination of ‘w’ for weights, ‘m’ for means, and ‘c’ for covars. Defaults to ‘wmc’. components

attributes:
    weights_ : array, shape (n_components,)
        This attribute stores the mixing weights for each mixture component.

    means_ : array, shape (n_components, n_features)
        Mean parameters for each mixture component.

    covars_ : array
        Covariance parameters for each mixture component. The shape depends on covariance_type:
        (n_components, n_features)             if 'spherical',
        (n_features, n_features)               if 'tied',
        (n_components, n_features)             if 'diag',
        (n_components, n_features, n_features) if 'full'
        converged_ : bool
        True when convergence was reached in fit(), False otherwise.

methods:
    aic(X)	Akaike information criterion for the current model fit
    bic(X)	Bayesian information criterion for the current model fit
    fit(X[, y])	Estimate model parameters with the expectation-maximization algorithm.
    get_params([deep])	Get parameters for this estimator.
    predict(X)	Predict label for data.
    predict_proba(X)	Predict posterior probability of data under each Gaussian in the model.
    sample([n_samples, random_state])	Generate random samples from the model.
    score(X[, y])	Compute the log probability under the model.
    score_samples(X)	Return the per-sample likelihood of the data under the model.
    set_params(**params)	Set the parameters of this estimator.
"""

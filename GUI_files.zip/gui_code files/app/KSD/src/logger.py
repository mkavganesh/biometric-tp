from pynput.keyboard import Key, Listener
import logging
from .time import Time
import os.path

# global_variable_for_storing_keyboard_data = ''

class KeyLogger():

	def __init__(
		self,
		# logFileDirectory="",
		# logFileName="KeyLog.txt",
		getTime=Time().getTime
        ):
		# self.logFileDirectory = logFileDirectory
		# self.logFileName = logFileName
		self.getTime = getTime
		self.recordingFlag = True
		self.string = ''

	# def setLogFileName(self, logFileName):
	# 	self.logFileName = logFileName

	# def setLogDirectoryName(self, setLogDirectory):
	# 	self.logFileDirectory = setLogDirectory

	def setRecoringFlag(self, flag):
		self.recordingFlag = flag

	def ready(self):
		# self.file = self.returnFileForWriting()
		self.string = ''

	# def returnFileForWriting(self):
	# 	# completeName = os.path.join(self.logFileDirectory,self.logFileName)
	# 	# return open(completeName, "w+")
	# 	return open(self.logFileDirectory + '//' + self.logFileName, "w+")

	def start(self):

		def on_press(key):
			if self.recordingFlag:
				# self.file.write('KeyDown\t{}\t{}\n'.format(key, self.getTime()))
				self.string += 'KeyDown\t{}\t{}\n'.format(key, self.getTime())
				# print('a')

		def on_release(key):
			if self.recordingFlag:
				# self.file.write('KeyUp\t{}\t{}\n'.format(key, self.getTime()))
				self.string += 'KeyUp\t{}\t{}\n'.format(key, self.getTime())

		self.listener = Listener(on_press=on_press, on_release=on_release)
		self.listener.start()

	def changeRecoringFlag(self):
		self.recordingFlag = not self.recordingFlag

	def stop(self):
		self.listener.stop()
		# self.file.close()

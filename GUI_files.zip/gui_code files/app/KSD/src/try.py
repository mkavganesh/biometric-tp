from sklearn.mixture import GaussianMixture
import pandas
# from EER_GMM import evaluateEER
import numpy as np
import warnings
warnings.filterwarnings("ignore")
np.set_printoptions(suppress=True)


def evaluateEER(user_scores, imposter_scores):
    thresholds = range(20, 51)
    array = np.zeros((len(thresholds), 3))
    i = 0
    for th in thresholds:
        g_i = 0
        i_g = 0
        for score in user_scores:
            if score < th:
                g_i = g_i + 1
        for score in imposter_scores:
            if score > th:
                i_g = i_g + 1

        FA = float(i_g) / len(imposter_scores)
        FR = float(g_i) / len(user_scores)
        array[i, 0] = th
        array[i, 1] = FA
        array[i, 2] = FR
        i = i + 1

    for j in range(array.shape[0]):
        if array[j, 1] < array[j, 2]:
            thresh = (array[j, 0] + array[j - 1, 0]) / 2
            break
    g_i = 0
    i_g = 0
    for score in user_scores:
        if score < thresh:
            g_i = g_i + 1
    for score in imposter_scores:
        if score > thresh:
            i_g = i_g + 1

    FA = float(i_g) / len(imposter_scores)
    FR = float(g_i) / len(user_scores)
    return (FA + FR) / 2

class GMMDetector:
    #the training(), testing() and evaluateEER() function change, rest all is same.

    def __init__(self, subjects):
        self.user_scores = []
        self.imposter_scores = []
        self.mean_vector = []
        self.subjects = subjects

    def training(self):
        self.gmm = GaussianMixture(n_components=3, covariance_type='diag',verbose=False)
        self.gmm.fit(self.train)
        # print(self.train)

    def testing(self):
        for i in range(self.test_genuine.shape[0]):
            j = (self.test_genuine.iloc[i].values).reshape(1,-1)
            cur_score = self.gmm.score(j)
            self.user_scores.append(cur_score)

        for i in range(self.test_imposter.shape[0]):
            j = (self.test_imposter.iloc[i].values).reshape(1, -1)
            cur_score = self.gmm.score(j)
            self.imposter_scores.append(cur_score)

    def evaluate(self):
        eers = []

        for subject in subjects:
            genuine_user_data = data.loc[data.subject == subject,
                                         "H.period":"H.Return"]
            imposter_data = data.loc[data.subject != subject, :]

            self.train = genuine_user_data[:200]
            self.test_genuine = genuine_user_data[200:]
            self.test_imposter = imposter_data.groupby("subject"). \
                head(5).loc[:, "H.period":"H.Return"]

            self.training()
            self.testing()
            eers.append(evaluateEER(self.user_scores,
                                    self.imposter_scores))
        return np.mean(eers)


path = "DSL-StrongPasswordData.csv"
data = pandas.read_csv(path)
subjects = data["subject"].unique()
print ("average EER for GMM detector:")
print(GMMDetector(subjects).evaluate())

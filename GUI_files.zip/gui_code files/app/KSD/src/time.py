from datetime import datetime


class Time():
  def __init__(
    self,
    timeFormat="%d:%m:%Y:%H:%M:%S:%f"
    ):
    self.timeFormat = timeFormat

  def getTime(self):
    return datetime.now().strftime(self.timeFormat)

  def timeToNumber(self, string):
    return datetime.timestamp(datetime.strptime(string, self.timeFormat))
import numpy as np
from .time import Time
# from collections import deque
# import pandas as pd

class Feature():

    def __init__(self):
        pass

    def extractFeatures(self, string):
        # temp_hold = []
        # temp_dd = []
        hold = []
        dd = []
        ud = []
        ups = []
        downs = []
        keys = {}
        time_object = Time()
        x = string.split('\n')
        for i in x:
            temp = i.split('\t')
            try:
                time_in_number = time_object.timeToNumber(temp[2])
                if temp[0] == 'KeyDown':
                    downs.append([temp[1], time_in_number])
                else:
                    ups.append([temp[1], time_in_number])
            except:
                pass
        for i in range(min(len(ups), len(downs))):
            time_diff = ups[i][1] - downs[i][1]
            hold.append(time_diff)
        for i in range(min(len(ups), len(downs))-1):
            time_diff = downs[i+1][1] - downs[i][1]
            dd.append(time_diff)
        for i in range(len(dd)):
            ud.append(dd[i] - hold[i])
        return np.array(hold), np.array(dd), np.array(ud)



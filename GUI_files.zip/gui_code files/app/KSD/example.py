# from src.model import Model
# from src.logger import KeyLogger
# from src.feature import Feature
import threading

from .src import *

import cv2 as cv
import time


def startKeyStrokeProcess(
	logFileDirectory="",
	logFileName="KeyLog.txt"
):
	global keyStrokeObject
	keyStrokeObject = KeyLogger(
            # logFileDirectory=logFileDirectory,
            # logFileName=logFileName
        )
	keyStrokeObject.ready()
	keyStrokeObject.start()


def pauseUnpauseKeyStrokeProcess():
	global keyStrokeObject
	keyStrokeObject.changeRecoringFlag()


def stopKeyStrokeProcess():
	keyStrokeObject.stop()


def start(
	record_key=True,
):
    if(record_key):
        thread_KeyStroke = threading.Thread(
            target=startKeyStrokeProcess,
            kwargs=dict(
                # logFileDirectory=directoryName,
                # logFileName=keyStrokeFileName,
            )
        )
        thread_KeyStroke.start()


def pauseUnpause():
	pauseUnpauseKeyStrokeProcess()


def stop(
	record_key=True,
):
	if record_key:
		stopKeyStrokeProcess()


keyStrokeObject = None
feature = Feature()
global_variable_for_storing_keyboard_data = ''
model = Model()

if __name__ == '__main__':
    while(1):

        global_variable_for_storing_keyboard_data = ''

        print('\n1. make model\n2. use model\n3. Exit\nEnter your option:')
        try:
            option = int(input())
        except:
            pass
        if option == 1:
            start()
            # time.sleep(10)
            thisisnothing = input()
            stop()
            hold, dd, ud = feature.extractFeatures(keyStrokeObject.string)
            model.fit([hold, dd, ud])
            model.save_model('./model')
        elif option == 2:
            start()
            # while(1):
            #     if cv.waitKey(1) == ord('`'):
            #         break
            # time.sleep(10)
            thisisnothing = input()
            stop()
            hold, dd, ud = feature.extractFeatures(keyStrokeObject.string)
            model.fit([hold, dd, ud])
            model_original = model.load_model('./model')
            # print(model.models)
            # print(model_original.models)
            score = model_original.check_similarity(model)
            if score > 0.90:
                model_original.update([hold, dd, ud])
            print('your score: ',score)
        elif option == 3:
            break
        else:
            continue
